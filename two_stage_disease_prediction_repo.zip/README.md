
# Two-Stage Disease Prediction System

A confidence-aware machine learning model for disease prediction based on symptoms. This repository contains the code, data, and documentation for the system proposed in the research paper:

> **"Two-Stage Disease Prediction System Using Confidence-Aware Machine Learning"**  
> *Mosammat Shimu Akter, Department of CSE, Gono University, Bangladesh*

## 📄 Abstract
This system aims to predict disease using common symptoms while also calculating the confidence of prediction. If the confidence is low, the system advises the user to undergo further medical testing (e.g., blood test, X-ray). This two-stage approach improves trust and interpretability of AI in healthcare.

## 📊 Figures
![Confidence vs Accuracy](confidence_vs_accuracy.png)  
*Figure 1: Comparison of average confidence scores between correct and incorrect predictions.*

![Model Accuracy Comparison](model_accuracy_comparison.png)  
*Figure 2: Accuracy comparison between previous models and the proposed system.*

## 📜 License
MIT License — free to use, modify, and share.

## 🤝 Contact
shimuakther206@gmail.com
